precision mediump float; 

uniform sampler2D TextureID; 

varying vec4 Color; 
varying vec2 TextureCoord; 
varying vec3 Normal; 

void main() {
    gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
}
