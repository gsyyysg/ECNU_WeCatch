uniform sampler2D diffuseMap;

varying mediump vec2  TexCoord;


void main()
{
//    mediump float lightIntensity = max(dot(normalize(vLightDir), normalize(vWorldNormal)), 0.);
//    lightIntensity *= vOneOverAttenuation;
    gl_FragColor = texture2D(diffuseMap, TexCoord);
//    gl_FragColor.xyz = gl_FragColor.xyz * lightIntensity;
    //gl_FragColor.a = 1.0;
    
//    gl_FragColor = vec4(1.0);
    
}
