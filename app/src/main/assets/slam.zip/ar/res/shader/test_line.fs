precision mediump float;

uniform sampler2D TextureID;

varying vec4 Color; 
varying vec2 TextureCoord; 
varying vec3 Normal;

void main() {
	float length = sqrt(Normal.x * Normal.x + Normal.y * Normal.y + Normal.z * Normal.z);
	float father = 0.5;
	if (length > 1.0 - father && length < 1.0) {
		float delta = length - (1.0 - father);
		float ratio = 1.0 - delta / father;
		gl_FragColor = vec4(1.0, 0.0, 0.0, ratio);
	}
	else {
		gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
	}
}
