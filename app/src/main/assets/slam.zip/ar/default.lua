app_controller = ae.ARApplicationController:shared_instance()
app_controller:require('./scripts/include.lua')
app = AR:create_application(AppType.Slam, "cat")
app:load_scene_from_json("res/simple_scene.json","demo_scene")
lua_handler = app:get_lua_handler()
scene = app:get_current_scene()
input_contoller = scene:get_input_controller()
gesture_controller = input_contoller:get_gesture_controller()
ray_caster = input_contoller:get_ray_caster()
update = 0
touch = 0
show_gesture_guide_move = false
show_gesture_guide_rotate = false
show_gesture_guide_singlemove = false



-- 场景加载完成, 执行动画效果
app.on_loading_finish = function()
AR:perform_after(500, finish_lelay_load)
initKnowledge ()



  -- 注册监听
  Event:addEventListener("Open_Book_Button", Open_Book_Button)
  Event:addEventListener("CLose_Book_Button", CLose_Book_Button)
  Event:addEventListener("Open_Knowledge_Button", Open_Knowledge_Button)
  Event:addEventListener("CLose_Knowledge_Button", CLose_Knowledge_Button)
  Event:addEventListener("Click_CN_Button", Click_CN_Button)
  Event:addEventListener("Click_EN_Button", Click_EN_Button)
  Event:addEventListener("StopGesturesVideo", StopGesturesVideo)


  --slam旋转模式
  --scene:set_slam_rotate_type(0)
  app.device:enable_front_camera()
  -- 开启离屏引导
  scene:set_show_offscreen_guidance(true)
  --scene:set_slam_move_limits(0, 5000)

  -- 初始化视频效果
  initVideoPlayers()
  initMusicUI()
  -- 初始化音频效果 - 手势音频
  GestureVideo()
  -- 初始化模型效果
  click_Go()

  -- 仅第一次加载场景 播放手势提示
  AR:perform_after(200, lelay_load)
  -- 设定画面以外的指导目标
  scene:set_offscreen_guidance_target("model")
---------------------------------------3D画线----------------------------------
local path = {}
--第一条线的端点坐标
  path[1] = ae.ARVec3:new_local(-240,-137,239)
  path[2] = ae.ARVec3:new_local(-295,-205,252)
  scene.lineGroup1:create_geometry_line(path, 0.45, ae.ARVec3:new_local(1.0, 1.0, 1.0), false)
  gline1=scene.lineGroup1:get_geometry_line()
  gline1:set_property_bool("enabled", false)
--第二条线的端点坐标
  path[1] = ae.ARVec3:new_local(57,35,222)
  path[2] = ae.ARVec3:new_local(57,5,285)
  scene.lineGroup2:create_geometry_line(path, 0.45, ae.ARVec3:new_local(1.0, 1.0, 1.0), false)
  gline2=scene.lineGroup2:get_geometry_line()
  gline2:set_property_bool("enabled", false)
 --第三条线的端点坐标
  path[1] = ae.ARVec3:new_local(68,-10,80)
  path[2] = ae.ARVec3:new_local(105,-67,135)
  scene.lineGroup3:create_geometry_line(path, 0.45, ae.ARVec3:new_local(1.0, 1.0, 1.0), false)
  gline3=scene.lineGroup3:get_geometry_line()
  gline3:set_property_bool("enabled", false)
  --------------------------------单指旋转，双指移动------------------------------
  AR:perform_after(200, function()
  scene.root:set_property_vec3("world_rotate_axis", ae.ARVec3:new_local(0,0,0))
  end)
  gesture_controller:set_property_string("continuous_interaction_mapping", "gesture_two_finger_scroll-interaction_plane_move")
  gesture_controller:set_property_string("continuous_interaction_mapping", "gesture_single_finger_scroll-interaction_rotate")
  scene.model:set_visible(false)
 --屏幕旋转
app.device.on_device_rotate = function(orientation)
    if(orientation == DeviceOrientation.Left) then
      rotateleft()

    elseif(orientation == DeviceOrientation.Right) then
      rotateright()
    end
end
end

function finish_lelay_load()
scene.model:set_visible(true)

end

function on_gesture_update(gesture)
  ARLOG("qa_test:gesture:on gesture update")
  ARLOG("qa_test:gesture:pos.x:"..gesture.pos.x)
  ARLOG("qa_test:gesture:pos.y:"..gesture.pos.y)
  ARLOG("qa_test:gesture:type:"..gesture.type)
  ARLOG("qa_test:gesture:time:"..gesture.time)
  ARLOG("qa_test:gesture:swipe_direction:"..gesture.swipe_direction)
  ARLOG("qa_test:gesture:delta_angle:"..gesture.delta_angle)

  if (gesture.type == "gesture_click") then

      local ray = ray_caster:ray_from_screen(gesture.pos)
      local hit_result = ray_caster:get_hit_result(ray, "first_hit")
      local result = hit_result["result"]
      if (result[0] ~= nil) then
        local node = result[0]["node"]
        if (node ~= nil) then
          gesture_controller:set_responser(node)
          local name = node:get_property_string("name")
          ARLOG("qa_test:hit entity with node = "..name)
        end
      end
  end
end
-- 初始化视频效果
function initVideoPlayers()

    video_dian = scene.guide_video_video_dian:video()
                                                        :path('res/media/video/video_dian.mp4')
                                                        :delay(0)
                                                        :repeat_count(1)
end
-- 初始化音频效果 - 手势音频
function GestureVideo()
   audio_intro = scene.root:audio()
                          :path('res/media/intro.mp3')
                          :repeat_count(1)
   music_dian = scene.reset:audio()
                          :path('res/media/music_dian.mp3')
                          :repeat_count(1)
   gesture_video_arrow  = scene.reset:audio()
                   :path('res/media/arrow.mp3')
                   :repeat_count(1)
   gesture_video_click  = scene.reset:audio()
                   :path('res/media/click.mp3')
                   :repeat_count(1)
end
-- 初始化模型效果
function click_Go()
  scene.model:set_visible(true)
  anim_init = scene.model:pod_anim()
        :repeat_count(1)
        :speed(1)
        :anim_name('init')
        :start()
  AR:perform_after(200, delePaly)
end
-- 播放旁白 : 判断播放顺序(首次非首次)
function delePaly()
  local  tally=AR:get_dataStore (2, "come.baidu.art.aiqiyi.case")

  if(tally~="a")then
    AR:perform_after(17500, play_Path)
  elseif(tally == "a")then
    AR:perform_after(200, play_Path)
  end
end

show_audio_intro_play = true
-- 播放旁白 : 模型
function play_Path()

           if(show_audio_intro_play)then

              audio_intro:on_complete(function()
                            -- 切换简介按钮关闭
                            switch_close_book_button()
                            scene.info_card:set_visible(false)
                            -- 手势再提示
                            AR:perform_after(200, second_lelay_load)
                          end)
                          :start()
           end
end
-- 切换简介按钮关闭
function switch_close_book_button()
  local mapData = ae.MapData:new()
  mapData:put_int("id", 20001)
  AR.current_application.lua_handler:send_message_tosdk(mapData)
end

-- 简介按钮打开
function Open_Book_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  stopALLMusicUI()
  scene.info_card:set_visible(true)
  show_second_lelay_load = true
  stopdian()
  show_audio_intro_play = true
  play_Path()
end
-- 简介按钮关闭
function CLose_Book_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  stop_CLose_Book_Button()

end

function stop_CLose_Book_Button()
  scene.info_card:set_visible(false)
  show_second_lelay_load = false
  stopdian()
  show_audio_intro_play = false
  audio_intro:stop()
end


-- 播放互动 : 模型点击
scene.model.on_click = function()


  if(showUI)then
    closeUI()
    switch_closeUI_button()
  end

  scene.model:set_touchable(false)

  anim_hd = scene.model:pod_anim()
        :repeat_count(1)
        :anim_name('hd')
        :on_complete(function()
            scene.model:set_touchable(true)

            if(showUI)then
              AR:perform_after(1000, openUI)
              AR:perform_after(1000, switch_openUI_button)
            end


        end)
        :start()

  audio_hd = scene.model:audio()
                          :path('res/media/hd.mp3')
                          :repeat_count(1)
                          :start()
end

-- ****************以下为手势播放效果******************--
function showdian()
  scene.guide_video_video_dian:set_visible(true)
  video_dian:start()
  music_dian:start()
end
function stopdian()
  scene.guide_video_video_dian:set_visible(false)
  video_dian:stop()
  music_dian:stop()
end
function yanchi()
  video_dian:start()
  music_dian:start()
end
function yanchixianshi( )
  scene.guide_video_video_dian:set_visible(true)
end
-- ****************以上为手势播放效果******************--

-- 第一次加载场景 播放手势提示
function lelay_load()
  local  tally=AR:get_dataStore (2, "come.baidu.art.aiqiyi.case")

  if(tally~="a")then
    --存数据
    AR:set_dataStore(2, "come.baidu.art.aiqiyi.case","a")
    AR:perform_after(1000, showdian)
    AR:perform_after(17000, stopdian)
  end
end

-- 手势再提示
function second_lelay_load()

    if(show_second_lelay_load)then

      --AR:perform_after(200, yanchi)
      --AR:perform_after(400, yanchixianshi)
      --AR:perform_after(16200, stopdian)
      show_second_lelay_load = false
    end
end


local index = 0
local show_second_lelay_load = false
local show_offscreen_button = false
local has_dismis_guide = false
local has_show_arrow = false
local has_show_slam_guide = false
----------------------------------重置位置--------------------------------
scene.reset.on_click = function()
    ARLOG('reset on_click')
    stop_arrow()
    stop_click()
    app:relocate_current_scene()
    app.slam:slam_reset(0.25,0.5,1000)
    reset_slam_with_face_to_camera(100)
end

-- function reset_slam_with_face_to_camera(delay)
--     first_reset = true
--     function reset_slam_face_to_camera()
--         app.slam:slam_reset(0.5,0.5,1000)
--     end
--     if (first_reset) then
--         first_reset = false
--         app.slam:slam_reset(0.5,0.5,1000)
--         AR:perform_after(delay, reset_slam_face_to_camera)
--     else
--         app.slam:slam_reset(0.5,0.5,1000)
--     end
-- end

app.offscreen_button_show = function()
    ARLOG('offscreen_button_show')
    show_offscreen_button = true
    if ((not has_show_arrow) and (not has_show_slam_guide)) then
        has_show_arrow = true
      --  scene.arrow_guide:set_visible(true)
        ae.LuaUtils:call_function_after_delay(3000, "hide_arrow_guide")
    else
        scene.reset:set_visible(true)
        play_arrow_click_music()
        frame_id = scene.reset:framePicture()
            :repeat_count(-1)
            :start()


    end
end

app.offscreen_button_hide = function()
    ARLOG('offscreen_button_hide')
    show_offscreen_button = false
    scene.reset:set_visible(false)
    stop_arrow()
    stop_click()
   -- scene.arrow_guide:set_visible(false)
    if (not has_dismis_guide) then
        has_dismis_guide = true
    end
end


function hide_arrow_guide()
    ARLOG('hide_arrow_guide')
    if (not has_dismis_guide) then
       -- scene.arrow_guide:set_visible(false)
        scene.reset:set_visible(true)
        play_arrow_click_music()
        frame_id = scene.reset:framePicture()
            :repeat_count(-1)
            :start()
    end
end

-- 播放离屏引导音效
function play_arrow_click_music()


    AR:perform_after(100, stop_music_arrow)

    AR:perform_after(200, play_arrow)
    AR:perform_after(4200, stop_arrow)

    AR:perform_after(4400, play_click)
    AR:perform_after(10400, stop_click)
end

function stop_music_arrow()
    scene.guide_video_video_dian:set_visible(false)
    video_dian:stop()
    music_dian:stop()
    scene.info_card:set_visible(false)
    switch_close_book_button()
    show_audio_intro_play = false
    audio_intro:stop()
    stopALLMusicUI()
end


-- 播放离屏引导音效
function play_arrow()
  if(show_offscreen_button)then
     gesture_video_arrow:start()
  end
end
-- 停止播放离屏引导音效
function stop_arrow()
  gesture_video_arrow:stop()
end
-- 播放离屏中心按钮音效
function play_click()
  if(show_offscreen_button)then
     gesture_video_click:start()
  end
end
-- 停止播放离屏中心按钮音效
function stop_click()
  gesture_video_click:stop()
end




function rotateleft()

end

function rotateright()

end

function StopGesturesVideo(event)
  local result = event.data['result']
  ARLOG('result'..result)
  scene.guide_video_video_dian:set_visible(false)
  video_dian:stop()
  music_dian:stop()
end

showUI = false
local initResult = "10000"

-- 知识UI按钮打开
function Open_Knowledge_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  showUI = true
  initResult = result
  openUI()
end
function openUI()
   -- 片跟模型动
  initflag()

  -- 初始线和片展示
  setLinetrue()
  if(initResult == "10001")then
    setCNtrue()
  elseif(initResult == "10002")then
    setENtrue()
  end
end
-- 知识UI按钮关闭
function CLose_Knowledge_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  showUI = false
  closeUI()
end
function closeUI()
  -- 线和片取消展示
  setLinefalse()
  setCNAllfalse()
  setENAllfalse()
  -- 声音消失
  stopALLMusicUI()
end

-- 切换点击模型通知关闭知识点
function switch_closeUI_button()
  local mapData = ae.MapData:new()
  mapData:put_int("id", 20002)
  AR.current_application.lua_handler:send_message_tosdk(mapData)
end

-- 切换点击模型通知关闭知识点
function switch_openUI_button()
  local mapData = ae.MapData:new()
  mapData:put_int("id", 20003)
  AR.current_application.lua_handler:send_message_tosdk(mapData)
end

-- 中文按钮打开
function Click_CN_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  -- 片切换中文
  setENAllfalse()
  setCNtrue()
  -- 声音消失
  stopALLMusicUI()
  initResult = "10001"
end
-- 英文按钮关闭
function Click_EN_Button(event)
  local result = event.data['result']
  ARLOG('result'..result)
  -- 片切换英文
  setCNAllfalse()
  setENtrue()
  -- 声音消失
  stopALLMusicUI()
  initResult = "10002"
end


-- 片跟模型动
function initflag()
  scene.huashifaxiandi:set_flag(4, true)
  scene.huashifaxiandi_click:set_flag(4, true)
  scene.huashifaxiandi_En:set_flag(4, true)
  scene.huashifaxiandi_click_En:set_flag(4, true)
  scene.shengcunniandai:set_flag(4, true)
  scene.shengcunniandai_click:set_flag(4, true)
  scene.shengcunniandai_En:set_flag(4, true)
  scene.shengcunniandai_click_En:set_flag(4, true)
  scene.shixing:set_flag(4, true)
  scene.shixing_click:set_flag(4, true)
  scene.shixing_En:set_flag(4, true)
  scene.shixing_click_En:set_flag(4, true)
end

function initKnowledge ()
  scene.huashifaxiandi:set_property_bool("ditach_parent_rotate", true)
  scene.huashifaxiandi_click:set_property_bool("ditach_parent_rotate", true)
  scene.huashifaxiandi_En:set_property_bool("ditach_parent_rotate", true)
  scene.huashifaxiandi_click_En:set_property_bool("ditach_parent_rotate", true)
  scene.shengcunniandai:set_property_bool("ditach_parent_rotate", true)
  scene.shengcunniandai_click:set_property_bool("ditach_parent_rotate", true)
  scene.shengcunniandai_En:set_property_bool("ditach_parent_rotate", true)
  scene.shengcunniandai_click_En:set_property_bool("ditach_parent_rotate", true)
  scene.shixing:set_property_bool("ditach_parent_rotate", true)
  scene.shixing_click:set_property_bool("ditach_parent_rotate", true)
  scene.shixing_En:set_property_bool("ditach_parent_rotate", true)
  scene.shixing_click_En:set_property_bool("ditach_parent_rotate", true)
end
-- 线显示
function setLinetrue()
  gline1:set_property_bool("enabled", true)
  gline2:set_property_bool("enabled", true)
  gline3:set_property_bool("enabled", true)
end
-- 线不显示
function setLinefalse()
  gline1:set_property_bool("enabled", false)
  gline2:set_property_bool("enabled", false)
  gline3:set_property_bool("enabled", false)
end
-- 初始中文片显示
function setCNtrue()
  scene.huashifaxiandi:set_visible(true)
  scene.shengcunniandai:set_visible(true)
  scene.shixing:set_visible(true)
end
-- 初始英文片显示
function setENtrue()
  scene.huashifaxiandi_En:set_visible(true)
  scene.shengcunniandai_En:set_visible(true)
  scene.shixing_En:set_visible(true)
end
-- 中文片点击状态不显示
function setCNclickfalse()
  scene.huashifaxiandi_click:set_visible(false)
  scene.shengcunniandai_click:set_visible(false)
  scene.shixing_click:set_visible(false)
end
-- 英文片点击状态不显示
function setENclickfalse()
  scene.huashifaxiandi_click_En:set_visible(false)
  scene.shengcunniandai_click_En:set_visible(false)
  scene.shixing_click_En:set_visible(false)
end
-- 所有中文片不显示
function setCNAllfalse()
  scene.huashifaxiandi:set_visible(false)
  scene.huashifaxiandi_click:set_visible(false)
  scene.shengcunniandai:set_visible(false)
  scene.shengcunniandai_click:set_visible(false)
  scene.shixing:set_visible(false)
  scene.shixing_click:set_visible(false)

end
-- 所有英文片不显示
function setENAllfalse()
  scene.huashifaxiandi_En:set_visible(false)
  scene.huashifaxiandi_click_En:set_visible(false)
  scene.shengcunniandai_En:set_visible(false)
  scene.shengcunniandai_click_En:set_visible(false)
  scene.shixing_En:set_visible(false)
  scene.shixing_click_En:set_visible(false)
end


-- 音频初始化
function initMusicUI()
  Huashifaxiandi_music  = scene.reset:audio()
                   :path('res/media/music/Huashifaxiandi.mp3')
                   :repeat_count(1)
  Huashifaxiandi_En_music  = scene.reset:audio()
                   :path('res/media/music/Huashifaxiandi_En.mp3')
                   :repeat_count(1)
  Shengcunniandai_music  = scene.reset:audio()
                   :path('res/media/music/Shengcunniandai.mp3')
                   :repeat_count(1)
  Shengcunniandai_En_music  = scene.reset:audio()
                   :path('res/media/music/Shengcunniandai_En.mp3')
                   :repeat_count(1)
  Shixing_music  = scene.reset:audio()
                   :path('res/media/music/Shixing.mp3')
                   :repeat_count(1)
  Shixing_En_music  = scene.reset:audio()
                   :path('res/media/music/Shixing_En.mp3')
                   :repeat_count(1)
end
-- 所有音频都通知
function stopALLMusicUI()
  Huashifaxiandi_music:stop()
  Huashifaxiandi_En_music:stop()
  Shengcunniandai_music:stop()
  Shengcunniandai_En_music:stop()
  Shixing_music:stop()
  Shixing_En_music:stop()
end


scene.huashifaxiandi.on_click = function()
  PreventConflictUI_CN()
  -- 切换状态
  scene.huashifaxiandi:set_visible(false)
  scene.huashifaxiandi_click:set_visible(true)
  -- 播放音频
  Huashifaxiandi_music:start()
  click_zhongwen()
end
scene.huashifaxiandi_click.on_click = function()
  stopALLMusicUI()
  scene.huashifaxiandi:set_visible(true)
  scene.huashifaxiandi_click:set_visible(false)
  Huashifaxiandi_music:start()
  click_zhongwen()
end
scene.huashifaxiandi_En.on_click = function()

  PreventConflictUI_EN()
  -- 切换状态
  scene.huashifaxiandi_En:set_visible(false)
  scene.huashifaxiandi_click_En:set_visible(true)
  -- 播放音频
  Huashifaxiandi_En_music:start()
  click_yingwen()
end
scene.huashifaxiandi_click_En.on_click = function()
  stopALLMusicUI()
  scene.huashifaxiandi_En:set_visible(true)
  scene.huashifaxiandi_click_En:set_visible(false)
  Huashifaxiandi_En_music:start()
  click_yingwen()
end

scene.shixing.on_click = function()
  PreventConflictUI_CN()
  -- 切换状态
  scene.shixing:set_visible(false)
  scene.shixing_click:set_visible(true)
  -- 播放音频
  Shixing_music:start()
  click_zhongwen()
end
scene.shixing_click.on_click = function()
  stopALLMusicUI()
  scene.shixing:set_visible(true)
  scene.shixing_click:set_visible(false)
  Shixing_music:start()
  click_zhongwen()
end
scene.shixing_En.on_click = function()
  PreventConflictUI_EN()
  -- 切换状态
  scene.shixing_En:set_visible(false)
  scene.shixing_click_En:set_visible(true)
  -- 播放音频
  Shixing_En_music:start()
  click_yingwen()
end
scene.shixing_click_En.on_click = function()
  stopALLMusicUI()
  scene.shixing_En:set_visible(true)
  scene.shixing_click_En:set_visible(false)
  Shixing_En_music:start()
  click_yingwen()
end

scene.shengcunniandai.on_click = function()
  PreventConflictUI_CN()
  -- 切换状态
  scene.shengcunniandai:set_visible(false)
  scene.shengcunniandai_click:set_visible(true)
  -- 播放音频
  Shengcunniandai_music:start()
  click_zhongwen()
end
scene.shengcunniandai_click.on_click = function()
  stopALLMusicUI()
  scene.shengcunniandai:set_visible(true)
  scene.shengcunniandai_click:set_visible(false)
  Shengcunniandai_music:start()
  click_zhongwen()
end
scene.shengcunniandai_En.on_click = function()
  PreventConflictUI_EN()
  -- 切换状态
  scene.shengcunniandai_En:set_visible(false)
  scene.shengcunniandai_click_En:set_visible(true)
  -- 播放音频
  Shengcunniandai_En_music:start()
  click_yingwen()
end
scene.shengcunniandai_click_En.on_click = function()
  stopALLMusicUI()
  scene.shengcunniandai_En:set_visible(true)
  scene.shengcunniandai_click_En:set_visible(false)
  Shengcunniandai_En_music:start()
  click_yingwen()
end

-- 中文模式下防止冲突
function PreventConflictUI_CN()
  switch_close_book_button()
  stop_CLose_Book_Button()
  -- 防止冲突
  stopALLMusicUI()
  setCNclickfalse()
  setCNtrue()
end
-- 英文模式下防止冲突
function PreventConflictUI_EN()
  switch_close_book_button()
  stop_CLose_Book_Button()
  -- 防止冲突
  stopALLMusicUI()
  setENclickfalse()
  setENtrue()
end

-- 点击中文卡片
function click_zhongwen()
  local mapData = ae.MapData:new()
  mapData:put_int("id", 20011)
  AR.current_application.lua_handler:send_message_tosdk(mapData)
end

-- 点击英文卡片
function click_yingwen()
  local mapData = ae.MapData:new()
  mapData:put_int("id", 20012)
  AR.current_application.lua_handler:send_message_tosdk(mapData)
end
